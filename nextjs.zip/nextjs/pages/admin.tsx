import { useRouter } from 'next/router'
import Head from 'next/head'

export default function Admin() {
  const router = useRouter()

  const handleLogout = async () => {
    const res = await fetch('/api/auth/logout', {
      method: 'POST',
    })

    if (res.ok) {
      router.push('/login')
    }
  }

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      backgroundColor: '#f0f0f0',
      padding: '2rem'
    }}>
      <Head>
        <title>Admin Dashboard - Next.js Docker Hello World</title>
      </Head>

      <main style={{
        width: '100%',
        maxWidth: '800px'
      }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '2rem'
        }}>
          <h1 style={{
            fontSize: '2rem',
            color: '#333',
            margin: 0
          }}>
            Admin Dashboard
          </h1>
          
          <button
            onClick={handleLogout}
            style={{
              backgroundColor: '#ff4444',
              color: 'white',
              border: 'none',
              padding: '0.5rem 1rem',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '1rem'
            }}
          >
            Logout
          </button>
        </div>

        <div style={{
          background: 'white',
          padding: '2rem',
          borderRadius: '8px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{
            fontSize: '1.5rem',
            color: '#333',
            marginBottom: '1rem'
          }}>
            Welcome to the Admin Area
          </h2>
          <p style={{
            color: '#666',
            lineHeight: '1.6'
          }}>
            This is a protected page that can only be accessed by authenticated users.
          </p>
        </div>
      </main>
    </div>
  )
} 