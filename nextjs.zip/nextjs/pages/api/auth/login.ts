import { NextApiRequest, NextApiResponse } from 'next'
import { serialize } from 'cookie'

const ADMIN_CREDENTIALS = {
  username: 'admin',
  password: 'Test#321@'
}

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' })
  }

  const { username, password } = req.body

  if (
    username === ADMIN_CREDENTIALS.username &&
    password === ADMIN_CREDENTIALS.password
  ) {
    // Set authentication cookie
    const token = Buffer.from(`${username}:${new Date().getTime()}`).toString('base64')
    
    res.setHeader(
      'Set-Cookie',
      serialize('auth_token', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        path: '/',
        maxAge: 3600 // 1 hour
      })
    )

    return res.status(200).json({ message: 'Logged in successfully' })
  }

  return res.status(401).json({ message: 'Invalid credentials' })
} 