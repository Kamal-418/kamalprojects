import type { NextPage } from 'next'
import Head from 'next/head'

const Home: NextPage = () => {
  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#f0f0f0'
    }}>
      <Head>
        <title>Next.js Docker Hello World</title>
        <meta name="description" content="A simple Next.js Docker application" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main style={{
        padding: '2rem',
        textAlign: 'center'
      }}>
        <h1 style={{
          fontSize: '3rem',
          marginBottom: '1rem',
          color: '#333'
        }}>
          Hello World! 👋
        </h1>
        <p style={{
          fontSize: '1.2rem',
          color: '#666'
        }}>
          Welcome to Next.js 12.2 running in Docker
        </p>
      </main>
    </div>
  )
}

export default Home 