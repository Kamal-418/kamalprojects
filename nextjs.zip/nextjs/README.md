# Next.js Docker Hello World

A simple Hello World application using Next.js 12.2 and Docker.

## Prerequisites

- Docker

## Building and Running the Application

1. Build the Docker image:
```bash
docker build -t nextjs-docker-hello .
```

2. Run the container:
```bash
docker run -p 3000:3000 nextjs-docker-hello
```

3. Open your browser and visit:
```
http://localhost:3000
```

## Development

To run the application in development mode without Docker:

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
``` 